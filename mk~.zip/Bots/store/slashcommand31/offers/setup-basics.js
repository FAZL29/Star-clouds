const { SlashCommandBuilder, ChannelType } = require("discord.js");
const { Database } = require("st.db");
const feedbackDB = new Database("/Json-db/Bots/offersDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('setup-basics')
        .setDescription('تحديد روم الاراء مع الرتبة و الكاتيجوري')
        .addChannelOption(option => 
            option.setName('room')
                .setDescription('روم الدلائل')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)) // استخدم ChannelType.GuildText هنا
        .addRoleOption(option => 
            option.setName('role')
                .setDescription('(استلام التكتات)رتبة السيلر')
                .setRequired(true))
        .addChannelOption(option => 
            option.setName('category')
                .setDescription('كاتيجوري الاستلام')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildCategory)) // استخدم ChannelType.GuildCategory هنا
        .addRoleOption(option => 
            option.setName('nasab-role')
                .setDescription('رتبة نصاب')
                .setRequired(true))
        .addRoleOption(option => 
            option.setName('mawtoq-role')
                .setDescription('رتبة موثوق')
                .setRequired(true)),

    async execute(interaction) {
        try {
            const room = interaction.options.getChannel('room');
            const role = interaction.options.getRole('role');
            const category = interaction.options.getChannel('category');
            const nasab = interaction.options.getRole('nasab-role');
            const mawtoq = interaction.options.getRole('mawtoq-role');

            await feedbackDB.set(`proof_cha_${interaction.guild.id}`, room.id);
            await feedbackDB.set(`claim_role_${interaction.guild.id}`, role.id);
            await feedbackDB.push(`claim_cate_${interaction.guild.id}`, category.id);
            await feedbackDB.set(`nasab_${interaction.guild.id}`, nasab.id);
            await feedbackDB.set(`mawtoq_${interaction.guild.id}`, mawtoq.id);

            return interaction.reply({
                content: `**تم تحديد الاعدادات بنجاح**.`
            });
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: '**حدث خطأ أثناء تحديد البيانات.**', ephemeral: true });
        }
    }
};
