
const { ChatInputCommandInteraction, Client, SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ChannelType } = require("discord.js");
const { Database } = require("st.db");
const offersDB = new Database("/Json-db/Bots/offersDB");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('add-claimablecat')
        .setDescription('اضافة كاتيجوري استلام')
        .addChannelOption(option =>
            option
                .setName('category')
                .setDescription('كاتيجوري استلام التكتات')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildCategory)), 
    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction) {
        try {
            await interaction.deferReply();

            const category = interaction.options.getChannel('category');
            const categoryId = category.id;

            const categories = offersDB.get(`claim_cate_${interaction.guild.id}`) || [];

            if (categories.includes(categoryId)) {
                let embed = new EmbedBuilder()
                    .setDescription(`⚠️ **الكاتيجوري موجودة بالفعل.**`)
                    .setColor('Yellow')
                    .setTimestamp()
                    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) });
                return interaction.editReply({ embeds: [embed] });
            }

            categories.push(categoryId);
            offersDB.set(`claim_cate_${interaction.guild.id}`, categories);

            let embed = new EmbedBuilder()
                .setDescription(`✅ **تمت إضافة الكاتيجوري إلى القائمة بنجاح.**`)
                .setColor('Green')
                .addFields({ name: 'كاتيجوري:', value: category.name, inline: true })
                .setTimestamp()
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) });
            return interaction.editReply({ embeds: [embed] });

        } catch (error) {
            let embed = new EmbedBuilder()
                .setDescription(`❌ **حدث خطأ أثناء الاضافة.**`)
                .setColor('Red')
                .setTimestamp()
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) });
            return interaction.editReply({ embeds: [embed] });
        }
    }
};
