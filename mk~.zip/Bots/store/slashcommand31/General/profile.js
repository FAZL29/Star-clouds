const { SlashCommandBuilder, ChatInputCommandInteraction, Client, EmbedBuilder, ActionRowBuilder, ButtonBuilder, AttachmentBuilder } = require("discord.js");
const { Database } = require("st.db");
const { createCanvas, loadImage, registerFont } = require('canvas');
registerFont('./Bots/store/handlers/DGTrikaRegular.ttf', { family: 'Trika' });
const sellersDB = new Database("/Json-db/Bots/sellersDB");
const points = new Database("./Json-db/Bots/pointsDB.json");
const offersDB = new Database("/Json-db/Bots/offersDB");

const CUSTOM_BACKGROUND = 'https://cdn.akamai.steamstatic.com/steamcommunity/public/images/items/383870/f42a85705dcb548ce6d26dc657630dc72b03d7d0.jpg';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('عرض بروفايل البائع')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('البائع')
                .setRequired(false)), 

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction) {
        try {
            await interaction.deferReply();
            const userId = interaction.options.getUser('user')?.id || interaction.user.id; // الحصول على معرف المستخدم
            const targetUser = await interaction.client.users.fetch(userId, { force: true }).catch(() => null);
            if (!targetUser) {
                return interaction.reply("لم يتم العثور على الشخص.");
            }

            const member = await interaction.guild.members.fetch(userId).catch(() => null);
            if (!member) {
                return interaction.reply("هذا الشخص طلع من السرفر");
            }

            // جلب البيانات
            const starRatings = sellersDB.get(`stars_${interaction.guild.id}_${userId}`) || [];
            const linksKey = `user_links_${interaction.guild.id}_${userId}`;
            const links = sellersDB.get(linksKey) || [];
            const totalLinks = links.length;
            const pointsKey = `points_${interaction.guild.id}_${userId}`;
            const points2 = points.get(pointsKey) || 0;

            let totalRating = 0;
            starRatings.forEach(rating => {
                if (rating >= 1 && rating <= 5) totalRating += rating;
            });

            let averageRating = starRatings.length > 0 
                ? (Math.round((totalRating / starRatings.length) * 10) / 10).toString() 
                : "0";

            const roles = member.roles.cache;
            const roleNassabId = offersDB.get(`nasab_${interaction.guild.id}`);
            const roleMawthoqId = offersDB.get(`mawtoq_${interaction.guild.id}`);
            const isNassab = roles.has(roleNassabId);
            const isMawthoq = roles.has(roleMawthoqId);

            let statusMessage = "";
            if (isNassab) {
                statusMessage = "نصاب";
            } else if (isMawthoq) {
                statusMessage = "موثوق";
            } else {
                statusMessage = "ليس نصاب ، لكن احذر";
            }

            const canvas = createCanvas(800, 400);
            const ctx = canvas.getContext('2d');

            try {
                // التحقق من وجود بانر للمستخدم
                const userBanner = member.user.bannerURL({ extension: 'png', size: 2048 });

                if (userBanner) {
                    const banner = await loadImage(userBanner);
                    ctx.drawImage(banner, 0, 0, canvas.width, canvas.height);
                    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                } else {
                    const customBg = await loadImage(CUSTOM_BACKGROUND).catch(() => null);
                    if (customBg) {
                        ctx.drawImage(customBg, 0, 0, canvas.width, canvas.height);
                        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                        ctx.fillRect(0, 0, canvas.width, canvas.height);
                    } else {
                        ctx.fillStyle = isNassab ? 'rgba(0, 0, 0, 1)' :
                                           isMawthoq ? 'rgba(255, 215, 0, 0.3)' :
                                           'rgba(13, 71, 161, 0.7)';
                        ctx.fillRect(0, 0, canvas.width, canvas.height);
                    }
                }

                // رسم الصورة الشخصية
                const avatar = await loadImage(targetUser.displayAvatarURL({ extension: 'png', size: 256 }));

                ctx.save();
                const avatarSize = 100;
                const avatarX = 50;
                const avatarY = 50;

                // إطار الصورة الشخصية
                ctx.beginPath();
                ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2 + 5, 0, Math.PI * 2);
                const glowColor = isMawthoq ? '#ffd700' : '#ffffff';
                ctx.shadowColor = glowColor;
                ctx.shadowBlur = 15;
                ctx.strokeStyle = glowColor;
                ctx.lineWidth = 3;
                ctx.stroke();

                // الصورة الشخصية
                ctx.beginPath();
                ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
                ctx.restore();

                ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
                ctx.shadowBlur = 5;

                ctx.font = 'bold 32px Arial';
                ctx.fillStyle = '#ffffff';
                ctx.textAlign = 'right';
                ctx.fillText(targetUser.tag, canvas.width - 30, 60);

                const ratingX = canvas.width - 450;
                ctx.fillText(`${averageRating} / 5`, ratingX, 60);

                const starX = ratingX + 30;
                const starY = 50;
                const starSize = 20;
                drawStar(ctx, starX, starY, starSize, true);

                ctx.font = '29px Trika';
                ctx.fillText(`النقاط : ${points2}`, 750, 160);
                ctx.fillText(`عدد التقييمات : ${starRatings.length}`, 750, 210);
                ctx.fillText(`عدد دلائل البيع داخل السرفر : ${totalLinks}`, 750, 260);
                ctx.fillText(`الحالة : ${statusMessage}`, 750, 310);

                const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'profile.png' });

                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`links_${userId}_${interaction.guild.id}`)
                            .setLabel('دلائل البيع')
                            .setStyle('Primary'),
                        new ButtonBuilder()
                            .setCustomId(`ratings_${userId}_${interaction.guild.id}`)
                            .setLabel('التقييمات')
                            .setStyle('Secondary')
                    );

                return interaction.editReply({ files: [attachment], components: [row] });

            } catch (error) {
                console.error('Error creating profile card:', error);
                return interaction.editReply('حدث خطأ أثناء إنشاء البطاقة. الرجاء المحاولة مرة أخرى.');
            }
        } catch (error) {
            console.error(error);
            return interaction.editReply('حدث خطأ غير متوقع.');
        }
    }
};

function drawStar(ctx, x, y, size, filled = true) {
    ctx.save();
    ctx.beginPath();
    ctx.translate(x, y);

    for (let i = 0; i < 5; i++) {
        ctx.lineTo(Math.cos((18 + i * 72) * Math.PI / 180) * size,
                    Math.sin((18 + i * 72) * Math.PI / 180) * size);
        ctx.lineTo(Math.cos((54 + i * 72) * Math.PI / 180) * (size / 2),
                    Math.sin((54 + i * 72) * Math.PI / 180) * (size / 2));
    }

    ctx.closePath();
    if (filled) {
        ctx.fillStyle = '#FFD700';
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 15;
        ctx.fill();
    } else {
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 2;
        ctx.stroke();
    }
    ctx.restore();
}
