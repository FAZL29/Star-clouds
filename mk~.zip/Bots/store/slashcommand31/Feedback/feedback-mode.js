const { SlashCommandBuilder } = require('@discordjs/builders');
const { Database } = require('st.db');
const feedbackDB = new Database("/Json-db/Bots/offersDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-emoji')
        .setDescription('تغيير الايموجي')
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('الايموجي')
                .setRequired(false)),
    async execute(interaction) {
        const mode = interaction.options.getString('mode');
        const emoji = interaction.options.getString('emoji') || '❤'; 

        await feedbackDB.set(`feedback_emoji_${interaction.guild.id}`, emoji);

        await interaction.reply({ content: `تم ظبط وضع الأراء على ${mode}`, ephemeral: true });
    },
};
