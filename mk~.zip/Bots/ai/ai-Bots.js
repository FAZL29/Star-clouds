const { Client, Collection, discord, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message, Attachment } = require("discord.js");
const { Database } = require("st.db");
const aiDB = new Database("/Json-db/Bots/aiDB.json");
const tokens = new Database("/tokens/tokens");
const { PermissionsBitField } = require('discord.js');
const { Hercai } = require('hercai');
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions");

let ai = tokens.get('ai');
if (!ai) return;

const path = require('path');
const { readdirSync } = require("fs");
let theowner;
ai.forEach(async (data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix, token, clientId, owner } = data;
  theowner = owner;
  const client29 = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,] });
  client29.commands = new Collection();
  require(`./handlers/events`)(client29);
  client29.events = new Collection();
  require(`../../events/requireBots/ai-commands`)(client29);
  const rest = new REST({ version: '10' }).setToken(token);
  client29.setMaxListeners(1000);

  client29.on("ready", async () => {
    try {
      await rest.put(
        Routes.applicationCommands(client29.user.id),
        { body: aiSlashCommands },
      );
    } catch (error) {
      console.error(error);
    }
  });

  client29.once('ready', () => {
    client29.guilds.cache.forEach(guild => {
      guild.members.fetch().then(members => {
        if (members.size < 10) {
          console.log(`AI bot : Guild: ${guild.name} has less than 10 members`);
        }
      }).catch(console.error);
    });
  });

  //------------- التحقق من وقت البوت --------------//
  client29.on("ready", async () => {
    setInterval(async () => {
      let BroadcastTokens = tokens.get(`ai`) || [];
      let thiss = BroadcastTokens.find((br) => br.token == token);
      if (thiss) {
        if (thiss.timeleft <= 0) {
          const user = await client29.users.cache.get(owner) || await client29.users.fetch(owner);
          const embed = new EmbedBuilder()
            .setDescription(`**مرحبا <@${thiss.owner}>،لقد انتهى اشتراك بوتك <@${thiss.clientId}>. النوع : AI\nالاشتراك انتهى**`)
            .setColor("DarkerGrey")
            .setTimestamp();
          await user.send({ embeds: [embed] }).catch((err) => { console.log(err); });

          const filtered = BroadcastTokens.filter((bo) => bo != thiss);
          await tokens.set(`ai`, filtered);
          await client29.destroy().then(async () => {
            console.log(`${clientId} Ended`);
          });
        }
      }
    }, 1000);
  });

  require(`./handlers/events`)(client29);

  const folderPath = path.join(__dirname, 'slashcommand29');
  client29.aiSlashCommands = new Collection();
  const aiSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("AI commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
  )) {
    for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
    )) {
      let command = require(`${folderPath}/${folder}/${file}`);
      if (command) {
        aiSlashCommands.push(command.data.toJSON());
        client29.aiSlashCommands.set(command.data.name, command);
        if (command.data.name) {
          table.addRow(`/${command.data.name}`, "🟢 Working");
        } else {
          table.addRow(`/${command.data.name}`, "🔴 Not Working");
        }
      }
    }
  }

  const folderPath2 = path.join(__dirname, 'slashcommand29');

  for (let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
    for (let fiee of (readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
      const commander = require(`${folderPath2}/${foldeer}/${fiee}`);
    }
  }

  require(`../../events/requireBots/ai-commands`)(client29);
  require("./handlers/events")(client29);

  for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
    const event = require(`./events/${file}`);
    if (event.once) {
      client29.once(event.name, (...args) => event.execute(...args));
    } else {
      client29.on(event.name, (...args) => event.execute(...args));
    }
  }

  const herc = new Hercai();

  client29.on('messageCreate', async message => {
    const chan = aiDB.get(`ai_room_${message.guild.id}`);
    if (message.channel.id === chan) {
      if (message.author.bot) return;

      try {
        await message.channel.sendTyping();
        const response = await herc.question({ model: "v3-beta", content: message.content });
        await message.reply(response.reply);
      } catch (error) {
        await message.reply('عذرًا، لقد واجهت بعض المشاكل أثناء محاولة الرد، حاول مرة أخرى!');
      }
    }
  });

  client29.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "help_general") {
      const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTitle('قائمة اوامر البوت')
        .setDescription('**لا توجد اوامر في هذا القسم حاليا**')
        .setTimestamp()
        .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setColor('DarkButNotBlack');
      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐').setDisabled(true),
        new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑'),
      );

      await interaction.update({ embeds: [embed], components: [btns] });
    } else if (interaction.customId === "help_owner") {
      const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTitle('قائمة اوامر البوت')
        .addFields(
         { name: `\`/set-ai-room\``, value: `لتحديد روم الذكاء الصناعي` },
        )
        .setTimestamp()
        .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setColor('DarkButNotBlack');
      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐'),
        new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑').setDisabled(true),
      );

      await interaction.update({ embeds: [embed], components: [btns] });
    }
  });

  client29.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand()) {

      if (interaction.user.bot) return;

      const command = client29.aiSlashCommands.get(interaction.commandName);

      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true });
        }
      }
      if (command.adminsonly === true) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: `❗ ***يجب أن تمتلك صلاحية الأدمن لاستخدام هذا الأمر***`, ephemeral: true });
        }
      }
      try {
        await command.execute(interaction);
      } catch (error) {
        return;
      }
    }
  });

  client29.login(token)
    .catch(async (err) => {
      const filtered = ai.filter(bo => bo != data);
      await tokens.set(`ai`, filtered);
      console.log(`${clientId} Not working and removed`);
    });
});
