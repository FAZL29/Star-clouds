const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const aiDB = new Database("/Json-db/Bots/aiDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-ai-room')
        .setDescription('تحديد روم الذكاء الصناعي')
        .addChannelOption(Option =>
            Option
                .setName('room')
                .setDescription('الروم')
                .setRequired(true)), // or false
    async execute(interaction) {
        try {
            const room = interaction.options.getChannel('room');
            await aiDB.set(`ai_room_${interaction.guild.id}`, room.id);
            return interaction.reply({ content: '**تم تحديد الروم بنجاح**' });
        } catch {
            return;
        }
    }
};
