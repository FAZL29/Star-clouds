const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const fs = require("fs");

const shopDB = new Database("/Json-db/Bots/shopDB.json");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('fast-add-product-goods')
        .setDescription('إضافة سلع لمنتج معين')
        .addStringOption(option =>
            option.setName('product_name')
                .setDescription('اسم المنتج')
                .setRequired(true)
        ),
    async execute(interaction) {
        const products = shopDB.get(`products_${interaction.guild.id}`);
        if (!products || products.length <= 0) {
            return interaction.reply({ content: `**لا يوجد منتجات لإضافة سلع إليها**`, ephemeral: true });
        }

        const productName = interaction.options.getString('product_name');
        const productFind = products.find(prod => prod.name === productName);

        if (!productFind) {
            return interaction.reply({ content: `**لا يوجد منتج بهذا الاسم**`, ephemeral: true });
        }

        if ((productFind.goods?.length || 0) >= 6000) {
            return interaction.reply({ content: `**هذا المنتج يحتوي بالفعل على 6000 سلعة أو أكثر، لا يمكن إضافة المزيد.**`, ephemeral: true });
        }

        await interaction.reply({
            content: `**قم برفع ملف يحتوي على السلع التي ترغب في إضافتها.**`,
            ephemeral: true,
        });

        const filter = m => m.author.id === interaction.user.id && m.attachments.size > 0;
        const collector = interaction.channel.createMessageCollector({ filter, time: 120000 });

        collector.on('collect', async message => {
            const attachment = message.attachments.first();

            if (attachment.name.endsWith(".txt")) {
                try {
                    const response = await fetch(attachment.url);
                    const text = await response.text();
                    const goods = text.split("\n").filter(line => line.trim() !== '');

                    if ((productFind.goods?.length || 0) + goods.length > 6000) {
                        return interaction.followUp({ content: `**إجمالي السلع بعد الإضافة سيتجاوز 6000. لا يمكن إضافة هذه الكمية.**`, ephemeral: true });
                    }

                    productFind.goods = [...(productFind.goods || []), ...goods];
                    await shopDB.set(`products_${interaction.guild.id}`, products);

                    const embed = new EmbedBuilder()
                        .setTitle(`**[✅] تم إضافة السلع إلى المنتج "${productName}" بنجاح**`)
                        .setColor('#000000')
                        .setTimestamp();

                    await interaction.followUp({ embeds: [embed], ephemeral: true });
                } catch (error) {
                    console.error(error);
                    await interaction.followUp({ content: `**حدث خطأ أثناء معالجة الملف.**`, ephemeral: true });
                }
            } else {
                await interaction.followUp({ content: `**الرجاء رفع ملف بصيغة \`.txt\`.**`, ephemeral: true });
            }
            collector.stop();
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.followUp({ content: `**انتهى الوقت، لم يتم رفع أي ملف.**`, ephemeral: true });
            }
        });
    }
};
