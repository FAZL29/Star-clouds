const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/shopDB.json");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('buy')
        .setDescription('شراء سلعة')
        .addStringOption(Option => 
            Option.setName('product')
                  .setDescription('اسم المنتج')
                  .setRequired(true)
        )
        .addIntegerOption(Option => 
            Option.setName('count')
                  .setDescription('الكمية')
                  .setRequired(true)
        ),

async execute(interaction) {
    return interaction.reply({
        content: 'تم تعطيل هذا الأمر بشكل نهائي وتحويله لبريفكس فقط، مثال:\n`!buy nitro`',
        ephemeral: false
    });
}

};
