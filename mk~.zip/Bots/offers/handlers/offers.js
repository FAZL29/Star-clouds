const { Events, ButtonBuilder, ButtonStyle, ActionRowBuilder, ChannelType, PermissionsBitField, EmbedBuilder } = require("discord.js");
const discordTranscripts = require("discord-html-transcripts");
const { Database } = require("st.db");
const offersDB = new Database("/Json-db/Bots/offersDB.json");

module.exports = (client31) => {
  client31.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isButton()) {
      let [type, userId] = interaction.customId.split('_');

      if (type === "aord") {
        const categoryId = offersDB.get(`offers_category_${interaction.guild.id}`);
        const category = interaction.guild.channels.cache.get(categoryId);

        if (!category || category.type !== ChannelType.GuildCategory) {
          return interaction.reply({ content: "يجب اعداد البوت من قبل الأونر", ephemeral: true });
        }

        const user = await interaction.guild.members.fetch(userId).catch(() => null);

        if (!user) {
          return interaction.reply({ content: "البائع طلع من السرفر", ephemeral: true });
        }

        const channelName = `order-${user.user.username}`;

        const channel = await interaction.guild.channels.create({
          name: channelName,
          type: ChannelType.GuildText,
          parent: category.id,
          permissionOverwrites: [
            {
              id: interaction.guild.id, // Everyone
              deny: [PermissionsBitField.Flags.ViewChannel],
            },
            {
              id: userId, // صاحب الزر
              allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
            },
            {
              id: interaction.user.id, // ضاغط الزر
              allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
            },
          ],
        });

      let desc = `
تم انشاء التكت الخاص بك بنجاح ، انتظر البائع من فضلك
- **تذكير :** السرفر غير مسؤول عن تعاملك دون وسيط
`;

        const embed = new EmbedBuilder()
          .setDescription(desc)
          .setColor("Random")
          .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
          .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
          .setTimestamp();

const row = new ActionRowBuilder()
  .addComponents(
    new ButtonBuilder()
      .setCustomId(`scome_${userId}`)
      .setLabel("إستدعاء البائع")
      .setStyle(ButtonStyle.Success)
  )
  .addComponents(
    new ButtonBuilder()
      .setCustomId(`closeoffer`)
      .setLabel("حذف التذكرة")
      .setStyle(ButtonStyle.Danger)
  );


        await channel.send({
          content: `<@${interaction.user.id}>, <@${userId}>`,
          embeds: [embed],
          components: [row],
        });

        await user.send(`لقد حصلت على طلب جديد تفقده : <#${channel.id}>`);

        return interaction.reply({ content: `<#${channel.id}>`, ephemeral: true });
      }

      if (type === "deloff") {
        if (interaction.user.id !== userId) {
          return interaction.reply({ content: "أنت لست صاحب المنشور", ephemeral: true });
        }

        const message = await interaction.channel.messages.fetch(interaction.message.id);
        if (message) {
          await message.delete();
          return interaction.reply({ content: "تم حذف المنشور بنجاح", ephemeral: true });
        } else {
          return interaction.reply({ content: "المنشور محذوف بالفعل", ephemeral: true });
        }
      }

if (type === "scome") {
  const user = await interaction.guild.members.fetch(userId).catch(() => null);

  if (!user) {
    return interaction.reply({ content: "البائع طلع من السرفر", ephemeral: true });
  }
  await user.send(`تم استدعائك في : <#${interaction.channel.id}>`);

  return interaction.reply({ content: `تم ارسال الاستدعاء الى البائع بنجاح`, ephemeral: false });
}

if (type === "closeoffer") {
  await interaction.reply({
    content: "**هل أنت متأكد من حذف التذكرة؟**",
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`confirmDelete_${interaction.channel.id}`)
          .setLabel("نعم")
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`cancelDelete_${interaction.channel.id}`)
          .setLabel("لا")
          .setStyle(ButtonStyle.Secondary)
      ),
    ],
    ephemeral: false,
  });
}

if (type === "confirmDelete") {
  const channel = interaction.guild.channels.cache.get(userId); // userId هنا يمثل ID القناة من customId

  // إنشاء الترانسكريبت
  const attachment = await discordTranscripts.createTranscript(channel, {
    poweredBy: false,
    footerText: `System Store By Magic Host`,
  });

  const transcriptsChannelId = offersDB.get(`trans_cha_${interaction.guild.id}`);
  const transcriptsChannel = interaction.guild.channels.cache.get(transcriptsChannelId);

  if (transcriptsChannel) {
    const embed = new EmbedBuilder()
      .setTitle(`**Transcripts For : ${channel.name}**`)
      .setColor("Random");

    await transcriptsChannel.send({ embeds: [embed], files: [attachment] });
  }

  await channel.delete();
}

if (type === "cancelDelete") {
  return interaction.message.delete(); // حذف رسالة التأكيد
}


    }
  });
};
