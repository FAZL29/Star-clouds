const { Client, Collection, discord, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message, Attachment } = require("discord.js");
const { Database } = require("st.db");
const Discord = require('discord.js');
const auctionDB = new Database("/Json-db/Bots/auctionDB.json");
const tokens = new Database("/tokens/tokens");
const { PermissionsBitField } = require('discord.js');
const { Hercai } = require('hercai');
const { CronJob } = require('cron');
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions");

let auction = tokens.get('auction');
if (!auction) return;

const path = require('path');
const { readdirSync } = require("fs");
let theowner;
auction.forEach(async (data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix, token, clientId, owner } = data;
  theowner = owner;
  const client30 = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,] });
  client30.commands = new Collection();
  require(`./handlers/events`)(client30);
  client30.events = new Collection();
  require(`../../events/requireBots/auction-commands`)(client30);
  const rest = new REST({ version: '10' }).setToken(token);
  client30.setMaxListeners(1000);

  client30.on("ready", async () => {
    try {
      await rest.put(
        Routes.applicationCommands(client30.user.id),
        { body: auctionSlashCommands },
      );
    } catch (error) {
      console.error(error);
    }
  });

  client30.once('ready', () => {
    client30.guilds.cache.forEach(guild => {
      guild.members.fetch().then(members => {
        if (members.size < 10) {
          console.log(`Auction bot : Guild: ${guild.name} has less than 10 members`);
        }
      }).catch(console.error);
    });
  });

  //------------- التحقق من وقت البوت --------------//
  client30.on("ready", async () => {
    setInterval(async () => {
      let BroadcastTokens = tokens.get(`auction`) || [];
      let thiss = BroadcastTokens.find((br) => br.token == token);
      if (thiss) {
        if (thiss.timeleft <= 0) {
          const user = await client30.users.cache.get(owner) || await client30.users.fetch(owner);
          const embed = new EmbedBuilder()
            .setDescription(`**مرحبا <@${thiss.owner}>، لقد انتهى اشتراك بوتك <@${thiss.clientId}>. النوع : مزاد\nالاشتراك انتهى**`)
            .setColor("DarkerGrey")
            .setTimestamp();
          await user.send({ embeds: [embed] }).catch((err) => { console.log(err); });

          const filtered = BroadcastTokens.filter((bo) => bo != thiss);
          await tokens.set(`auction`, filtered);
          await client30.destroy().then(async () => {
            console.log(`${clientId} Ended`);
          });
        }
      }
    }, 1000);
  });

  require(`./handlers/events`)(client30);

  const folderPath = path.join(__dirname, 'slashcommand30');
  client30.auctionSlashCommands = new Collection();
  const auctionSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("Auction commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
  )) {
    for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
    )) {
      let command = require(`${folderPath}/${folder}/${file}`);
      if (command) {
        auctionSlashCommands.push(command.data.toJSON());
        client30.auctionSlashCommands.set(command.data.name, command);
        if (command.data.name) {
          table.addRow(`/${command.data.name}`, "🟢 Working");
        } else {
          table.addRow(`/${command.data.name}`, "🔴 Not Working");
        }
      }
    }
  }

  const folderPath2 = path.join(__dirname, 'slashcommand30');

  for (let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
    for (let fiee of (readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
      const commander = require(`${folderPath2}/${foldeer}/${fiee}`);
    }
  }

  require(`../../events/requireBots/auction-commands`)(client30);
  require("./handlers/events")(client30);

  for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
    const event = require(`./events/${file}`);
    if (event.once) {
      client30.once(event.name, (...args) => event.execute(...args));
    } else {
      client30.on(event.name, (...args) => event.execute(...args));
    }
  }

function parseBid(bid) {
    if (bid.endsWith('k')) return parseFloat(bid) * 1000;
    if (bid.endsWith('m')) return parseFloat(bid) * 1000000;
    return parseFloat(bid);
}

function formatBid(bid) {
    if (bid >= 1000000) return `${(bid / 1000000).toFixed(1)}m`;
    if (bid >= 1000) return `${(bid / 1000).toFixed(1)}k`;
    return bid.toString();
}

const auctions = {};

client30.on('messageCreate', async message => {
const kimomazad = await auctionDB.get(`auction_role_${message.guild.id}`);
  if(message.content == `${prefix}auction`) {
            if (!message.member.roles.cache.has(kimomazad)) {
              return;
          }
        const button = new Discord.ButtonBuilder()
            .setCustomId('startAuction')
            .setLabel('بدء المزاد')
            .setStyle(Discord.ButtonStyle.Success);

        const row = new Discord.ActionRowBuilder().addComponents(button);

        await message.reply({ content: 'اضغط علي الزر لانشاء المزاد.', components: [row] });
    }
}); 
client30.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
        if (interaction.customId === 'startAuction') {
            const modal = new Discord.ModalBuilder()
                .setCustomId('startAuctionModal')
                .setTitle('Start Auction');

            const itemInput = new Discord.TextInputBuilder()
                .setCustomId('itemInput')
                .setLabel("السلعه")
                .setStyle(Discord.TextInputStyle.Paragraph)
                .setPlaceholder('اكتب اسم السلعه.');
            const startingBidInput = new Discord.TextInputBuilder()
                .setCustomId('startingBidInput')
                .setLabel("السعر المبدئي")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('اكتب سعر المبدئي (بالارقام فقط).');
            const durationInput = new Discord.TextInputBuilder()
                .setCustomId('durationInput')
                .setLabel("زمن المزاد")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('اكتب زمن المزاد بالدقائق مثال ( 1m , 20m )');
            const imageInput = new Discord.TextInputBuilder()
                .setCustomId('imageInput')
                .setLabel("صورة السلعة")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('صورة السلعة اذا لم يكن لديك اكتب 0');
            const ownerInput = new Discord.TextInputBuilder()
                .setCustomId('owneract')
                .setLabel("صاحب السلعة")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('قم بوضع ايدي صاحب السلعة'); 
 const row1 = new Discord.ActionRowBuilder().addComponents(itemInput);
            const row2 = new Discord.ActionRowBuilder().addComponents(startingBidInput);
            const row3 = new Discord.ActionRowBuilder().addComponents(durationInput);
            const row4 = new Discord.ActionRowBuilder().addComponents(imageInput);
            const row5 = new Discord.ActionRowBuilder().addComponents(ownerInput);

            modal.addComponents(row1, row2, row3, row4, row5);

            await interaction.showModal(modal);
        }

        if (interaction.customId === 'placeBid') {
            const modal = new Discord.ModalBuilder()
                .setCustomId('bidModal')
                .setTitle('Place Your Bid');

            const priceInput = new Discord.TextInputBuilder()
                .setCustomId('priceInput')
                .setLabel("سـعـرك")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('أدخل السعر الخاص بك');
            const row = new Discord.ActionRowBuilder().addComponents(priceInput);
            modal.addComponents(row);

            await interaction.showModal(modal);
        }
    }

    if (interaction.customId === 'startAuctionModal') {
        const item = interaction.fields.getTextInputValue('itemInput');
        const startingBid = parseFloat(interaction.fields.getTextInputValue('startingBidInput'));
        const duration = parseInt(interaction.fields.getTextInputValue('durationInput'));
        const image = interaction.fields.getTextInputValue('imageInput');
        const owneract = interaction.fields.getTextInputValue('owneract');
        const channelName = await auctionDB.get(`auction_room_${interaction.guild.id}`);

        if (!item || isNaN(startingBid) || isNaN(duration) || duration <= 0) {
            return interaction.reply({ content: 'لقد وضعت شيء خاطئ حاول مجددا.', ephemeral: true });
        }

        const channel = client30.channels.cache.get(channelName);
        auctions[channel.id] = {
            item,
            highestBid: startingBid,
            highestBidder: null,
            bids: [],
            endTime: Date.now() + duration * 60000,
            image: image === '0' ? null : image,
            owneract
        };

        const { embeds, components } = await createAuctionEmbed(item, startingBid, duration, image === '0' ? null : image);
        if (embeds) {
            await channel.send({ embeds, components });
        } else {
            await interaction.reply({ content: 'حدث خطأ عند صنع ايمبيد المزاد.', ephemeral: true });
        }
        

        const job = new CronJob(new Date(Date.now() + duration * 60000), () => {
            endAuction(channel.id);
        });
        job.start();

        await interaction.reply({ content: 'تم بدأ المزاد بنجاح !', ephemeral: true });
    }

if (interaction.customId === 'bidModal') {
    const auction = auctions[interaction.channel.id];
    if (!auction) {
        return interaction.reply({ content: 'لقد انتهي المزاد بالفعل .', ephemeral: true });
    }

    const rawPriceInput = interaction.fields.getTextInputValue('priceInput');
    const newPrice = parseBid(rawPriceInput);

    if (newPrice === null || newPrice <= auction.highestBid) {
        return interaction.reply({ content: 'حدث خطأ يجب أن تضع رقم أعلي من أعلي سعر للمزايدة .', ephemeral: true });
    }

    auction.highestBid = newPrice;
    auction.highestBidder = interaction.user.id;
    auction.bids.push({ bidder: interaction.user.username, amount: newPrice });
    await updateAuctionEmbed(interaction.channel, auction);
    await interaction.reply({ content: `انت الأن صاحب اعلي مزايدة للآن السعر الذي وضعته : $${newPrice}`, ephemeral: true });
    }
  });

client30.on('modalSubmit', async interaction => {
    if (interaction.customId === 'startAuctionModal') {
        const item = interaction.fields.getTextInputValue('itemInput');
        const startingBid = parseFloat(interaction.fields.getTextInputValue('startingBidInput'));
        const duration = parseInt(interaction.fields.getTextInputValue('durationInput'));
        const image = interaction.fields.getTextInputValue('imageInput');
        const channelName = interaction.fields.getTextInputValue('channelInput');

        if (!item || isNaN(startingBid) || isNaN(duration) || duration <= 0) {
            return interaction.reply({ content: 'لقد وضعت شيء خاطئ حاول مجددا.', ephemeral: true });
        }

        const channel = client30.channels.cache.find(c => c.name === channelName || c.id === channelName);
        if (!channel) {
            return interaction.reply({ content: 'روم المزاد خاطئ تأكد من الاسم او الأيدي.', ephemeral: true });
        }

        auctions[channel.id] = {
            item,
            highestBid: startingBid,
            highestBidder: null,
            bids: [],
            endTime: Date.now() + duration * 60000,
            image: image === '0' ? null : image
        };

        const { embeds, components } = await createAuctionEmbed(item, startingBid, duration, image === '0' ? null : image);
        const auctionMessage = await channel.send({ content: `**أعلى سعر للآن :** $${startingBid}\n**صاحب أخر مزايدة :** لا مزايدات بعد`, embeds, components });
    
        auctions[channel.id].messageId = auctionMessage.id;

        const job = new CronJob(new Date(Date.now() + duration * 60000), () => {
            endAuction(channel.id);
        });
        job.start();

        await interaction.reply({ content: 'تم بدأ المزاد بنجاح !', ephemeral: true });
    }
}); 
async function createAuctionEmbed(item, startingBid, duration, image) {
  if (!item || isNaN(startingBid) || !duration) {
      console.error("Invalid parameters provided.");
      return; 
  }

const auctionEmbed = new EmbedBuilder()
    .setColor(0x0099ff)
    .setTitle('مـزاد جـديـد')
    .setDescription('زايد على هذه السلعة!')
    .addFields(
        { name: 'السلعة', value: item || 'لا توجد سلعة' },
        { name: 'السعر المبدئي', value: formatBid(startingBid) },
        { name: 'أعلى سعر مزايدة', value: formatBid(startingBid) },
        { name: 'صاحب أعلى سعر مزايدة', value: 'لا مزايدات بعد' },
        { name: 'ينتهي في', value: `<t:${Math.floor((Date.now() + duration * 60000) / 1000)}:R>` }
    )
    .setFooter({ text: 'Auction Bot' });


  if (image) {
      auctionEmbed.setImage(image);
  }

  const placeBidButton = new Discord.ButtonBuilder()
      .setCustomId('placeBid')
      .setLabel('مـزايـدة')
      .setStyle(Discord.ButtonStyle.Primary);

  const row = new Discord.ActionRowBuilder().addComponents(placeBidButton);

  return { embeds: [auctionEmbed], components: [row] }; 
}
async function updateAuctionEmbed(channel, auction) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const auctionMessage = messages.find(msg => msg.embeds.length > 0 && msg.embeds[0].title === 'مـزاد جـديـد');

  if (auctionMessage) {
      const highestBidMessage = `**أعلى سعر للآن:** ${formatBid(auction.highestBid) || 'لا مزايدات بعد'}\n**أعلى مزايد:** ${auction.highestBidder ? `<@${auction.highestBidder}>` : 'لا مزايدين بعد'}`;

      const updatedEmbed = Discord.EmbedBuilder.from(auctionMessage.embeds[0])
          .spliceFields(2, 2,
              { name: 'أعلي سعر مزايدة', value: `$${auction.highestBid || 'No bids'}` },
              { name: 'صاحب أعلي سعر مزايدة', value: auction.highestBidder ? `<@${auction.highestBidder}>` : 'No bids yet' }
          );

      try {
          await auctionMessage.edit({ content: highestBidMessage, embeds: [updatedEmbed] });
      } catch (error) {
          console.error("Error updating auction embed:", error);
      }
  }
}
async function endAuction(channelId) {
    const auction = auctions[channelId];
    if (!auction) return;

    const channel = await client30.channels.fetch(channelId);
    await channel.send(`لقد انتهي المزاد .
مبروك لـ <@${auction.highestBidder || 'No one'}> 

تواصل مع <@${auction.owneract}>.`);
    delete auctions[channelId];
}

  client30.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "help_general") {
      const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTitle('قائمة اوامر البوت')
        .setDescription('**لا توجد اوامر في هذا القسم حاليا**')
        .setTimestamp()
        .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setColor('DarkButNotBlack');
      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐').setDisabled(true),
        new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑'),
      );

      await interaction.update({ embeds: [embed], components: [btns] });
    } else if (interaction.customId === "help_owner") {
      const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTitle('قائمة اوامر البوت')
        .addFields(
         { name: `\`/setup-auction\``, value: `تسطيب نظام المزاد` },
         {name : `\`${prefix}auction\`` , value : `لانشاء مزاد`},
        )
        .setTimestamp()
        .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setColor('DarkButNotBlack');
      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐'),
        new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑').setDisabled(true),
      );

      await interaction.update({ embeds: [embed], components: [btns] });
    }
  });

  client30.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand()) {

      if (interaction.user.bot) return;

      const command = client30.auctionSlashCommands.get(interaction.commandName);

      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true });
        }
      }
      if (command.adminsonly === true) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: `❗ ***يجب أن تمتلك صلاحية الأدمن لاستخدام هذا الأمر***`, ephemeral: true });
        }
      }
      try {
        await command.execute(interaction);
      } catch (error) {
        return;
      }
    }
  });

  client30.login(token)
    .catch(async (err) => {
      const filtered = auction.filter(bo => bo != data);
      await tokens.set(`auction`, filtered);
      console.log(`${clientId} Not working and removed`);
    });
});
