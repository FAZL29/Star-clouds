const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, Message } = require("discord.js");
const { Database } = require("st.db");
const Discord = require('discord.js');
const setting = new Database("/database/settingsdata/setting");
const usersdata = new Database(`/database/usersdata/usersdata`);
const prices = new Database("/database/settingsdata/prices");
const invoices = new Database("/database/settingsdata/invoices");
const { PermissionsBitField } = require('discord.js');
const tokens = new Database("/tokens/tokens");
const { CronJob } = require('cron');
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions");
const auctionDB = new Database("/Json-db/Bots/auctionDB.json");

let auction = tokens.get(`auction`);
const path = require('path');
const { readdirSync } = require("fs");

module.exports = {
  name: Events.InteractionCreate,
  /**
   * @param {Interaction} interaction
   */
  async execute(interaction) {
    if (interaction.isModalSubmit()) {
      if (interaction.customId == "BuyAuction_Modal") {
        await interaction.deferReply({ ephemeral: true });
        let userbalance = parseInt(usersdata.get(`balance_${interaction.user.id}_${interaction.guild.id}`));
        const Bot_token = interaction.fields.getTextInputValue(`Bot_token`);
        const Bot_prefix = interaction.fields.getTextInputValue(`Bot_prefix`);

        const client30 = new Client({
          intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent],
          shards: "auto",
          partials: [Partials.Message, Partials.Channel, Partials.GuildMember]
        });

        try {
          const owner = interaction.user.id;
          let price1 = prices.get(`auction_price_${interaction.guild.id}`) || 40;
          price1 = parseInt(price1);

          function generateRandomCode() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let code = '';
            for (let i = 0; i < 12; i++) {
              if (i > 0 && i % 4 === 0) {
                code += '-';
              }
              const randomIndex = Math.floor(Math.random() * characters.length);
              code += characters.charAt(randomIndex);
            }
            return code;
          }

          const invoice = generateRandomCode();
          const { REST } = require('@discordjs/rest');
          const rest = new REST({ version: '10' }).setToken(Bot_token);
          const { Routes } = require('discord-api-types/v10');

          client30.on("ready", async () => {
            let doneembeduser = new EmbedBuilder()
              .setTitle(`**تم انشاء بوتك بنجاح**`)
              .setDescription(`**معلومات الفاتورة :**`)
              .addFields(
                { name: `**الفاتورة**`, value: `**\`${invoice}\`**`, inline: false },
                { name: `**نوع البوت**`, value: `**\`مزاد\`**`, inline: false },
                { name: `**توكن البوت**`, value: `**\`${Bot_token}\`**`, inline: false },
                { name: `**البريفكس**`, value: `**\`${Bot_prefix}\`**`, inline: false }
              );
            await invoices.set(`${invoice}_${interaction.guild.id}`, {
              type: `مزاد`,
              token: `${Bot_token}`,
              prefix: `${Bot_prefix}`,
              userid: `${interaction.user.id}`,
              guildid: `${interaction.guild.id}`,
              serverid: `عام`,
              price: price1
            });

            const newbalance = parseInt(userbalance) - parseInt(price1);
            await usersdata.set(`balance_${interaction.user.id}_${interaction.guild.id}`, newbalance);

            const thebut = new ButtonBuilder()
              .setLabel(`دعوة البوت`)
              .setStyle(ButtonStyle.Link)
              .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client30.user.id}&permissions=8&scope=bot%20applications.commands`);
            const rowss = new ActionRowBuilder().addComponents(thebut);
            await interaction.user.send({ embeds: [doneembeduser], components: [rowss] });
          });

          let doneembedprove = new EmbedBuilder()
            .setColor('Aqua')
            .setDescription(`**تم شراء بوت \`مزاد\` بواسطة : ${interaction.user}**`)
            .setTimestamp();
          let logroom = setting.get(`log_room_${interaction.guild.id}`);
          let theroom = interaction.guild.channels.cache.find(ch => ch.id == logroom);
          await theroom.send({ embeds: [doneembedprove] });

          const { WebhookClient } = require('discord.js');
          const { purchaseWebhookUrl } = require('../../config.json');
          const webhookClient = new WebhookClient({ url: purchaseWebhookUrl });
          const theEmbed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('تمت عملية شراء جديدة')
            .addFields(
              { name: `نوع البوت`, value: `\`\`\`مزاد\`\`\``, inline: true },
              { name: `سعر البوت`, value: `\`\`\`${price1}\`\`\``, inline: true },
              { name: `المشتري`, value: `\`\`\`${interaction.user.username} , [${interaction.user.id}]\`\`\``, inline: true },
              { name: `السيرفر`, value: `\`\`\`${interaction.guild.name} [${interaction.guild.id}]\`\`\``, inline: true },
              { name: `صاحب السيرفر`, value: `\`\`\`${interaction.guild.ownerId}\`\`\``, inline: true },
              { name: `الفاتورة`, value: `\`\`\`${invoice}\`\`\``, inline: false }
            );
          await webhookClient.send({ embeds: [theEmbed] });

          let userbots = usersdata.get(`bots_${interaction.user.id}_${interaction.guild.id}`);
          if (!userbots) {
            await usersdata.set(`bots_${interaction.user.id}_${interaction.guild.id}`, 1);
          } else {
            userbots = userbots + 1;
            await usersdata.set(`bots_${interaction.user.id}_${interaction.guild.id}`, userbots);
          }

          await interaction.editReply({ content: `**تم انشاء بوتك بنجاح وتم خصم \`${price1}\` من رصيدك**` });

          client30.commands = new Collection();
          client30.events = new Collection();
          require("../../Bots/auction/handlers/events")(client30);
          require("../../events/requireBots/auction-commands")(client30);
          const folderPath = path.resolve(__dirname, '../../Bots/auction/slashcommand30');
          const prefix = Bot_prefix;
          client30.auctionSlashCommands = new Collection();
          const auctionSlashCommands = [];
          const ascii = require("ascii-table");
          const table = new ascii("auction commands").setJustify();
          for (let folder of readdirSync(folderPath).filter((folder) => !folder.includes("."))) {
            for (let file of readdirSync(`${folderPath}/` + folder).filter((f) => f.endsWith(".js"))) {
              let command = require(`${folderPath}/${folder}/${file}`);
              if (command) {
                auctionSlashCommands.push(command.data.toJSON());
                client30.auctionSlashCommands.set(command.data.name, command);
                if (command.data.name) {
                  table.addRow(`/${command.data.name}`, "🟢 Working");
                } else {
                  table.addRow(`/${command.data.name}`, "🔴 Not Working");
                }
              }
            }
          }

          const folderPath3 = path.resolve(__dirname, '../../Bots/auction/handlers');
          for (let file of readdirSync(folderPath3).filter(f => f.endsWith('.js'))) {
            const event = require(path.join(folderPath3, file))(client30);
          }


function parseBid(bid) {
    if (bid.endsWith('k')) return parseFloat(bid) * 1000;
    if (bid.endsWith('m')) return parseFloat(bid) * 1000000;
    return parseFloat(bid);
}

function formatBid(bid) {
    if (bid >= 1000000) return `${(bid / 1000000).toFixed(1)}m`;
    if (bid >= 1000) return `${(bid / 1000).toFixed(1)}k`;
    return bid.toString();
}

const auctions = {};

client30.on('messageCreate', async message => {
const kimomazad = await auctionDB.get(`auction_role_${message.guild.id}`);
  if(message.content == `${prefix}auction`) {
            if (!message.member.roles.cache.has(kimomazad)) {
              return;
          }
        const button = new Discord.ButtonBuilder()
            .setCustomId('startAuction')
            .setLabel('بدء المزاد')
            .setStyle(Discord.ButtonStyle.Success);

        const row = new Discord.ActionRowBuilder().addComponents(button);

        await message.reply({ content: 'اضغط علي الزر لانشاء المزاد.', components: [row] });
    }
}); 
client30.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
        if (interaction.customId === 'startAuction') {
            const modal = new Discord.ModalBuilder()
                .setCustomId('startAuctionModal')
                .setTitle('Start Auction');

            const itemInput = new Discord.TextInputBuilder()
                .setCustomId('itemInput')
                .setLabel("السلعه")
                .setStyle(Discord.TextInputStyle.Paragraph)
                .setPlaceholder('اكتب اسم السلعه.');
            const startingBidInput = new Discord.TextInputBuilder()
                .setCustomId('startingBidInput')
                .setLabel("السعر المبدئي")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('اكتب سعر المبدئي (بالارقام فقط).');
            const durationInput = new Discord.TextInputBuilder()
                .setCustomId('durationInput')
                .setLabel("زمن المزاد")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('اكتب زمن المزاد بالدقائق مثال ( 1m , 20m )');
            const imageInput = new Discord.TextInputBuilder()
                .setCustomId('imageInput')
                .setLabel("صورة السلعة")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('صورة السلعة اذا لم يكن لديك اكتب 0');
            const ownerInput = new Discord.TextInputBuilder()
                .setCustomId('owneract')
                .setLabel("صاحب السلعة")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('قم بوضع ايدي صاحب السلعة'); 
 const row1 = new Discord.ActionRowBuilder().addComponents(itemInput);
            const row2 = new Discord.ActionRowBuilder().addComponents(startingBidInput);
            const row3 = new Discord.ActionRowBuilder().addComponents(durationInput);
            const row4 = new Discord.ActionRowBuilder().addComponents(imageInput);
            const row5 = new Discord.ActionRowBuilder().addComponents(ownerInput);

            modal.addComponents(row1, row2, row3, row4, row5);

            await interaction.showModal(modal);
        }

        if (interaction.customId === 'placeBid') {
            const modal = new Discord.ModalBuilder()
                .setCustomId('bidModal')
                .setTitle('Place Your Bid');

            const priceInput = new Discord.TextInputBuilder()
                .setCustomId('priceInput')
                .setLabel("سـعـرك")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder('أدخل السعر الخاص بك');
            const row = new Discord.ActionRowBuilder().addComponents(priceInput);
            modal.addComponents(row);

            await interaction.showModal(modal);
        }
    }

    if (interaction.customId === 'startAuctionModal') {
        const item = interaction.fields.getTextInputValue('itemInput');
        const startingBid = parseFloat(interaction.fields.getTextInputValue('startingBidInput'));
        const duration = parseInt(interaction.fields.getTextInputValue('durationInput'));
        const image = interaction.fields.getTextInputValue('imageInput');
        const owneract = interaction.fields.getTextInputValue('owneract');
        const channelName = await auctionDB.get(`auction_room_${interaction.guild.id}`);

        if (!item || isNaN(startingBid) || isNaN(duration) || duration <= 0) {
            return interaction.reply({ content: 'لقد وضعت شيء خاطئ حاول مجددا.', ephemeral: true });
        }

        const channel = client30.channels.cache.get(channelName);
        auctions[channel.id] = {
            item,
            highestBid: startingBid,
            highestBidder: null,
            bids: [],
            endTime: Date.now() + duration * 60000,
            image: image === '0' ? null : image,
            owneract
        };

        const { embeds, components } = await createAuctionEmbed(item, startingBid, duration, image === '0' ? null : image);
        if (embeds) {
            await channel.send({ embeds, components });
        } else {
            await interaction.reply({ content: 'حدث خطأ عند صنع ايمبيد المزاد.', ephemeral: true });
        }
        

        const job = new CronJob(new Date(Date.now() + duration * 60000), () => {
            endAuction(channel.id);
        });
        job.start();

        await interaction.reply({ content: 'تم بدأ المزاد بنجاح !', ephemeral: true });
    }

if (interaction.customId === 'bidModal') {
    const auction = auctions[interaction.channel.id];
    if (!auction) {
        return interaction.reply({ content: 'لقد انتهي المزاد بالفعل .', ephemeral: true });
    }

    const rawPriceInput = interaction.fields.getTextInputValue('priceInput');
    const newPrice = parseBid(rawPriceInput);

    if (newPrice === null || newPrice <= auction.highestBid) {
        return interaction.reply({ content: 'حدث خطأ يجب أن تضع رقم أعلي من أعلي سعر للمزايدة .', ephemeral: true });
    }

    auction.highestBid = newPrice;
    auction.highestBidder = interaction.user.id;
    auction.bids.push({ bidder: interaction.user.username, amount: newPrice });
    await updateAuctionEmbed(interaction.channel, auction);
    await interaction.reply({ content: `انت الأن صاحب اعلي مزايدة للآن السعر الذي وضعته : $${newPrice}`, ephemeral: true });
    }
  });

client30.on('modalSubmit', async interaction => {
    if (interaction.customId === 'startAuctionModal') {
        const item = interaction.fields.getTextInputValue('itemInput');
        const startingBid = parseFloat(interaction.fields.getTextInputValue('startingBidInput'));
        const duration = parseInt(interaction.fields.getTextInputValue('durationInput'));
        const image = interaction.fields.getTextInputValue('imageInput');
        const channelName = interaction.fields.getTextInputValue('channelInput');

        if (!item || isNaN(startingBid) || isNaN(duration) || duration <= 0) {
            return interaction.reply({ content: 'لقد وضعت شيء خاطئ حاول مجددا.', ephemeral: true });
        }

        const channel = client30.channels.cache.find(c => c.name === channelName || c.id === channelName);
        if (!channel) {
            return interaction.reply({ content: 'روم المزاد خاطئ تأكد من الاسم او الأيدي.', ephemeral: true });
        }

        auctions[channel.id] = {
            item,
            highestBid: startingBid,
            highestBidder: null,
            bids: [],
            endTime: Date.now() + duration * 60000,
            image: image === '0' ? null : image
        };

        const { embeds, components } = await createAuctionEmbed(item, startingBid, duration, image === '0' ? null : image);
        const auctionMessage = await channel.send({ content: `**أعلى سعر للآن :** $${startingBid}\n**صاحب أخر مزايدة :** لا مزايدات بعد`, embeds, components });
    
        auctions[channel.id].messageId = auctionMessage.id;

        const job = new CronJob(new Date(Date.now() + duration * 60000), () => {
            endAuction(channel.id);
        });
        job.start();

        await interaction.reply({ content: 'تم بدأ المزاد بنجاح !', ephemeral: true });
    }
}); 
async function createAuctionEmbed(item, startingBid, duration, image) {
  if (!item || isNaN(startingBid) || !duration) {
      console.error("Invalid parameters provided.");
      return; 
  }

const auctionEmbed = new EmbedBuilder()
    .setColor(0x0099ff)
    .setTitle('مـزاد جـديـد')
    .setDescription('زايد على هذه السلعة!')
    .addFields(
        { name: 'السلعة', value: item || 'لا توجد سلعة' },
        { name: 'السعر المبدئي', value: formatBid(startingBid) },
        { name: 'أعلى سعر مزايدة', value: formatBid(startingBid) },
        { name: 'صاحب أعلى سعر مزايدة', value: 'لا مزايدات بعد' },
        { name: 'ينتهي في', value: `<t:${Math.floor((Date.now() + duration * 60000) / 1000)}:R>` }
    )
    .setFooter({ text: 'Auction Bot' });


  if (image) {
      auctionEmbed.setImage(image);
  }

  const placeBidButton = new Discord.ButtonBuilder()
      .setCustomId('placeBid')
      .setLabel('مـزايـدة')
      .setStyle(Discord.ButtonStyle.Primary);

  const row = new Discord.ActionRowBuilder().addComponents(placeBidButton);

  return { embeds: [auctionEmbed], components: [row] }; 
}
async function updateAuctionEmbed(channel, auction) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const auctionMessage = messages.find(msg => msg.embeds.length > 0 && msg.embeds[0].title === 'مـزاد جـديـد');

  if (auctionMessage) {
      const highestBidMessage = `**أعلى سعر للآن:** ${formatBid(auction.highestBid) || 'لا مزايدات بعد'}\n**أعلى مزايد:** ${auction.highestBidder ? `<@${auction.highestBidder}>` : 'لا مزايدين بعد'}`;

      const updatedEmbed = Discord.EmbedBuilder.from(auctionMessage.embeds[0])
          .spliceFields(2, 2,
              { name: 'أعلي سعر مزايدة', value: `$${auction.highestBid || 'No bids'}` },
              { name: 'صاحب أعلي سعر مزايدة', value: auction.highestBidder ? `<@${auction.highestBidder}>` : 'No bids yet' }
          );

      try {
          await auctionMessage.edit({ content: highestBidMessage, embeds: [updatedEmbed] });
      } catch (error) {
          console.error("Error updating auction embed:", error);
      }
  }
}
async function endAuction(channelId) {
    const auction = auctions[channelId];
    if (!auction) return;

    const channel = await client30.channels.fetch(channelId);
    await channel.send(`لقد انتهي المزاد .
مبروك لـ <@${auction.highestBidder || 'No one'}> 

تواصل مع <@${auction.owneract}>.`);
    delete auctions[channelId];
}

          client30.on("interactionCreate", async (interaction) => {
            if (interaction.customId === "help_general") {
              const embed = new EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle('قائمة اوامر البوت')
                .setDescription('**لا توجد اوامر في هذا القسم حاليا**')
                .setTimestamp()
                .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setColor('DarkButNotBlack');
              const btns = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐').setDisabled(true),
                new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑')
              );

              await interaction.update({ embeds: [embed], components: [btns] });
            } else if (interaction.customId === "help_owner") {
              const embed = new EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle('قائمة اوامر البوت')
                .addFields(
                { name: `\`/setup-auction\``, value: `تسطيب نظام المزاد` },
                {name : `\`${prefix}auction\`` , value : `لانشاء مزاد`}
                )
                .setTimestamp()
                .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setColor('DarkButNotBlack');
              const btns = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐'),
                new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑').setDisabled(true)
              );

              await interaction.update({ embeds: [embed], components: [btns] });
            }
          });

          client30.on('ready', async () => {
            setInterval(async () => {
              let BroadcastTokenss = tokens.get(`auction`);
              let thiss = BroadcastTokenss.find(br => br.token == Bot_token);
              if (thiss) {
                if (thiss.timeleft <= 0) {
                  console.log(`${client30.user.id} Ended`);
                  await client30.destroy();
                }
              }
            }, 1000);
          });

          client30.on("ready", async () => {
            try {
              await rest.put(
                Routes.applicationCommands(client30.user.id),
                { body: auctionSlashCommands },
              );
            } catch (error) {
              console.error(error);
            }
          });

          const folderPath2 = path.resolve(__dirname, '../../Bots/auction/events');
          for (let file of readdirSync(folderPath2).filter(f => f.endsWith('.js'))) {
            const event = require(path.join(folderPath2, file));
          }

          client30.on("interactionCreate", async (interaction) => {
            if (interaction.isChatInputCommand()) {
              if (interaction.user.bot) return;

              const command = client30.auctionSlashCommands.get(interaction.commandName);

              if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
              }
              if (command.ownersOnly === true) {
                if (owner != interaction.user.id) {
                  return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true });
                }
              }
              if (command.adminsOnly === true) {
                if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                  return interaction.reply({ content: `❗ ***يجب أن تمتلك صلاحية الأدمن لاستخدام هذا الأمر***`, ephemeral: true });
                }
              }
              try {
                await command.execute(interaction);
              } catch (error) {
                console.error(`Error executing ${interaction.commandName}`);
                console.error(error);
              }
            }
          });

          await client30.login(Bot_token).catch(async () => {
            return interaction.editReply({ content: `**فشل التحقق , الرجاء تفعيل اخر ثلاث خيارات في قائمة البوت**` });
          });

          if (!auction) {
            await tokens.set(`auction`, [{ token: Bot_token, prefix: Bot_prefix, clientId: client30.user.id, owner: interaction.user.id, timeleft: 2629744 }]);
          } else {
            await tokens.push(`auction`, { token: Bot_token, prefix: Bot_prefix, clientId: client30.user.id, owner: interaction.user.id, timeleft: 2629744 });
          }

        } catch (error) {
          console.error(error);
          return interaction.editReply({ content: `**قم بتفعيل الخيارات الثلاثة او التاكد من توكن البوت ثم اعد المحاولة**` });
        }
      }
    }
  }
};
